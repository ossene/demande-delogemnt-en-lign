
<?php
session_start();
$sp=mysqli_connect("localhost","root","","demande");
         if($sp->connect_errno){
                echo "Error <br/>".$sp->error;
}

$picpath="etudiantphoto/";
$docpath="etudiantdoc/";
$proofpath="etudiantinfo/";
$id=$_SESSION['user'];
if(isset($_POST['fpicup']))
{
$picpath=$picpath.$_FILES['fpic']['name'];
$docpath1=$docpath.$_FILES['ftndoc']['name'];     
$docpath2=$docpath.$_FILES['ftcdoc']['name']; 
$proofpath2=$docpath.$_FILES['fdmdoc']['name']; 
$docpath4=$docpath.$_FILES['fdcdoc']['name'];     
$proofpath1=$proofpath.$_FILES['fide']['name']; 


if(move_uploaded_file($_FILES['fpic']['tmp_name'],$picpath)
  && move_uploaded_file($_FILES['ftndoc']['tmp_name'],$docpath1)
  && move_uploaded_file($_FILES['ftcdoc']['tmp_name'],$docpath2)
  && move_uploaded_file($_FILES['fdmdoc']['tmp_name'],$proofpath2)
  && move_uploaded_file($_FILES['fdcdoc']['tmp_name'],$docpath4)
  && move_uploaded_file($_FILES['fide']['tmp_name'],$proofpath1))
{

$img=$_FILES['fpic']['name'];
$img1=$_FILES['ftndoc']['name'];
$img2=$_FILES['ftcdoc']['name'];
$img3=$_FILES['fdmdoc']['name'];
$img4=$_FILES['fdcdoc']['name'];
$img5=$_FILES['fide']['name'];


$query="insert into document (s_id,PHOTO,FICHE_INSCRIPTION,PHOTOCOPE_BACC_RELEVE,
    CNI, DROIT_LOGEMENT, CERTIFICA_RESIDENCE) values 
    ('$id','$img','$img1','$img2','$img3','$img4','$img5')";
        if($sp->query($query)){
     echo "Inserted to DB ";    
    }else
    {
        echo "Error <br/>".$sp->error;        
    }
}
else
{
echo "There is an error,please retry or ckeck path";
}
}
 ?>
